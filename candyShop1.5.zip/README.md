# candyShop
    Candy Shop es un sitio de venta mayorista y a gran escala de golosinas y productos en general a kioscos, grugstore, supermercados y shops en general. Apunta a la distribución de dichos productos a locales que revenden en cantidad o unitarios al consumidor final.

Webs de referencia:
https://masmelos.com.ar/
	Fuerte impacto con respecto a promociones, no permite compra sin registro, pero si muestra precios y descuentos.

https://www.delipop.com.ar/ofertas.php
	Venta por combos. Error que no se pueden ver los productos totales sin filtrado. Scroll animado de las marcas, se podría generar una interacción para el filtrado de productos.

https://www.distribuidorapop.com.ar/
	Página en la cual detectamos varios errores que no queremos cometer, como por ej. la poca identidad de la marca en sí. Lo bueno, diversidad de rubros y posibilidad de compra por bulto.

https://santaanagolosinas.com.ar/
	Producto muy básico y minimalista. Cuenta con header fijo al hacer el scroll.

https://www.felfort.com.ar/
	Transiciones del landing y ser una marca líder del mercado.

https://www.farmacity.com/
	Diseño interesante del header al scrollear la web, buena adaptación a móvil.

https://tienda.mercadolibre.com.ar/arcor
	Por ser tienda oficial en el Marketplace más popular local.

https://www.mms.com/es-es/
	Estética, calidad y personalización de productos, página extranjera....
    



Colores:
 Amarillo: #FBE454
 Rosas: #ED1E79 #F6398B 
 Violeta: #5b007f
 Celeste: #84d2f1

Enlace tablero
https://trello.com/b/WlSeniwJ

 //npm run start

-------------------
BASE DE DATOS
-------------------
sequelize db:migrate
sequelize db:seed:all

Usuarios Admin

	user: hbaravalle@digitalhouse.com
	pass: Milanesa123

	user: uriel@digitalhouse.com
	pass: Milanesa123


// © >_cuarentenialCoders </primeTeam>