** SPRINT 2 (Retro sobre el SP1) **
- Al comienzo de este segundo Sprint notamos que tendriamos que haber puesto mas detalle en el maquetado del sitio.

** SPRINT 3 (Retro sobre el SP2) **
- Mejoramos la distribucion de tareas, que en el sprint anterior nos superpusimos tareas.

** SPRINT 4 (Retro sobre el SP3) **
- En el sprint anterior avanzamos con cosas que no estaban pedidas, que nos resolvio mucho este sprint.